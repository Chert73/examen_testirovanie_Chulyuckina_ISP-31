﻿using System;

namespace examen2
{
    class Program
    {
        public static int[,] RandomArray()
        {
            Random rand = new Random();
            int n = rand.Next(5, 10);
            int m = rand.Next(5, 10);
            int[,] array = new int[n, m];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    array[i, j] = rand.Next(-20, 20);
                    Console.Write(array[i, j] + "\t");
                }
                Console.WriteLine();
            }
            return array;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Задание: В матрице m x n. Отсортировать по убыванию элементы строк, расположенные после второго отрицательного числа.");
            int[,] array = RandomArray();
            for (int i = 0; i < array.GetLength(0); i++)
            {
                int count = 0;
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (array[i, j] < 0) count++;
                    if (count == 2)
                    {
                        int divider = j + 1;
                        while (divider < array.GetLength(1))//сортировка выбором (selection sort)
                        {
                            int max = divider;
                            for (int t = divider; t < array.GetLength(1); t++)
                            {
                                if (array[i, t] > array[i, max]) max = t;
                            }
                            if (max != divider)
                            {
                                int tmp = array[i, max];
                                array[i, max] = array[i, divider];
                                array[i, divider] = tmp;
                            }
                            divider++;
                        }
                    }
                }
            }

            Console.WriteLine();
            for (int i = 0; i < array.GetLength(0); i++)//вывод результата
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    Console.Write(array[i, j] + "\t");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }

    }
}
